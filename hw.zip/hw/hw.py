import webbrowser as wb
wb.open("https://www.youtube.com/watch?v=dQw4w9WgXcQ")